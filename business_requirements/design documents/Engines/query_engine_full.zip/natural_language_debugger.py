def explain_dsl(dsl_model):
    explanation = "Filtering " + dsl_model["target"] + " based on:\n"
    for f in dsl_model["filters"]:
        explanation += f"- {f['field']} {f['operator']} {f['value']}\n"
    return explanation