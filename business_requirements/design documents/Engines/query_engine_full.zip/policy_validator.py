def enforce_policy(query_model, user_context):
    allowed_fields = user_context.get("allowed_fields", [])
    query_model["filters"] = [f for f in query_model["filters"] if f["field"] in allowed_fields]
    return query_model