_cache = {}

def get_from_cache(query_hash):
    return _cache.get(query_hash)

def store_in_cache(query_hash, result):
    _cache[query_hash] = result