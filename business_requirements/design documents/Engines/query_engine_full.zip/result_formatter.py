def format_result(result):
    return {
        "type": "table",
        "columns": ["supplier", "spend", "esgScore", "endDate"],
        "rows": result["data"]
    }