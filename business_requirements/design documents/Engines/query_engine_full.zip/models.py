from dataclasses import dataclass
from typing import List, Dict

@dataclass
class QueryIntent:
    target: str
    filters: List[Dict]

@dataclass
class QueryResult:
    data: List[Dict]
    metadata: Dict