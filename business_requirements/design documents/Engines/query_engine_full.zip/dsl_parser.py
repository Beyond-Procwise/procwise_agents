def parse_prompt_to_dsl(intent, entities):
    filters = []
    if "spend_gt" in entities:
        filters.append({"field": "contract.spend", "operator": ">", "value": entities["spend_gt"]})
    if "esg_score" in entities:
        filters.append({"field": "supplier.esg_score", "operator": "=", "value": entities["esg_score"]})
    if "contract_end_before" in entities:
        filters.append({"field": "contract.end_date", "operator": "<", "value": entities["contract_end_before"]})
    return {"target": "supplier", "filters": filters}