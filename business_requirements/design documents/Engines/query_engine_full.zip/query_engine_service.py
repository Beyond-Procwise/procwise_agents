from dsl_parser import parse_prompt_to_dsl
from policy_validator import enforce_policy
from query_executor import execute_query
from result_formatter import format_result

def run_query(prompt_intent, entities, user_context):
    query_model = parse_prompt_to_dsl(prompt_intent, entities)
    compliant_query = enforce_policy(query_model, user_context)
    result = execute_query(compliant_query)
    return format_result(result)