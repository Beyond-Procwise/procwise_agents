def log_query(user_id, query_model, result):
    print(f"LOG: {user_id} ran query: {query_model} and received: {result}")