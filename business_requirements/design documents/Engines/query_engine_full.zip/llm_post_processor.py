def summarize_result(result):
    rows = result.get("rows", [])
    if not rows:
        return "No suppliers matched the criteria."
    return f"{len(rows)} suppliers matched the filters with notable spend and ESG risk."