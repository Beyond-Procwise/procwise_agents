def execute_query(query_model):
    # Simulated backend call
    return {
        "data": [
            {"supplier": "Supplier A", "spend": 120000, "esgScore": "low", "endDate": "2025-09-01"},
            {"supplier": "Supplier B", "spend": 110000, "esgScore": "low", "endDate": "2025-08-15"}
        ]
    }