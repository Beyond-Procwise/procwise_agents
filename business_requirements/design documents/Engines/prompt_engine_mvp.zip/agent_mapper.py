def map_to_agents(intent: str, entities: dict) -> list:
    if intent == "contract_renegotiation":
        return ["BenchmarkAgent", "ContractIntelligenceAgent", "LLMDraftingAgent"]
    if intent == "supplier_comparison":
        return ["SupplierComparisonAgent", "QuoteEvaluationAgent"]
    if intent == "spend_query":
        return ["SpendAnalyticsAgent"]
    if intent == "savings_detection":
        return ["OpportunityMinerAgent", "CostOptimizerAgent"]
    if intent == "supplier_outreach":
        return ["LLMDraftingAgent", "SupplierInteractionAgent"]
    return []