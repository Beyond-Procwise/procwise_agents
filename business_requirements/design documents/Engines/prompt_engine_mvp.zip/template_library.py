templates = {
    "contract_renegotiation": "Renegotiate with {supplier} for {category}. Review clauses and suggest alternatives.",
    "supplier_comparison": "Compare suppliers: {supplier}. Evaluate cost, performance, and risk.",
    "spend_query": "What is our total spend with {supplier} for {category} in {time_range}?",
    "savings_detection": "Analyze current contracts and invoices to find cost-saving opportunities.",
    "supplier_outreach": "Draft and send RFP to shortlisted suppliers in category {category}."
}