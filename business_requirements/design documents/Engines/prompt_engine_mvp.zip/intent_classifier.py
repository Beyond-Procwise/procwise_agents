def classify_intent(text: str) -> str:
    if "renegotiate" in text.lower():
        return "contract_renegotiation"
    if "compare" in text.lower() and "supplier" in text.lower():
        return "supplier_comparison"
    if "spend" in text.lower():
        return "spend_query"
    if "savings" in text.lower():
        return "savings_detection"
    if "rfp" in text.lower() or "send" in text.lower():
        return "supplier_outreach"
    return "unknown"