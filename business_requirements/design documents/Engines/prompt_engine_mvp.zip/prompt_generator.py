from template_library import templates

def generate_prompt(intent: str, entities: dict) -> str:
    template = templates.get(intent, "Default prompt: No specific template found.")
    try:
        return template.format(**entities)
    except KeyError as e:
        missing_key = str(e).strip("'")
        return f"Incomplete data: Missing '{missing_key}' for generating prompt."