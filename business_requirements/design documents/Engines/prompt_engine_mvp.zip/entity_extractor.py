def extract_entities(text: str) -> dict:
    entities = {}
    if "Supplier X" in text:
        entities["supplier"] = "Supplier X"
    if "Supplier A" in text and "Supplier B" in text:
        entities["supplier"] = ["Supplier A", "Supplier B"]
    if "software" in text.lower():
        entities["category"] = "Software"
    if "100,000" in text or "100000" in text:
        entities["amount"] = 100000
    if "cloud" in text.lower():
        entities["category"] = "Cloud Services"
    if "2024" in text:
        entities["time_range"] = "2024 YTD"
    return entities