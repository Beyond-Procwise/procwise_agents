def check_policy_compliance(intent: str, entities: dict, user_id: str = None) -> (bool, str):
    if intent == "contract_renegotiation" and entities.get("amount", 0) > 100000:
        return False, "Only senior managers can initiate high-value renegotiations."
    if intent == "supplier_comparison" and not entities.get("supplier"):
        return False, "Supplier must be specified for comparison."
    return True, None